using NEXO.data;
using NEXO.services;
using NEXO.Controllers;
using NEXO.Views;

namespace NEXO
{
    class Program
    {
        static void Main(string[] args)
        {
            var conexao = new Conexao();
            var senhaService = new SenhaService();
            var usuarioService = new UsuarioService(conexao, senhaService);
            var produtoService = new ProdutoService(conexao);
            
            var catalogoController = new CatalogoController(produtoService);
            var menuView = new MenuView(catalogoController);

            menuView.ExibirMenuPlataformas();
        }
    }
}