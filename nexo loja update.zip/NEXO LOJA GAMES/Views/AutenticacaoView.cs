using System;
using NEXO.Controllers;

namespace NEXO.Views
{
    public class AutenticacaoView
    {
        private readonly AutenticacaoController _autenticacaoController;

        public AutenticacaoView(AutenticacaoController autenticacaoController)
        {
            _autenticacaoController = autenticacaoController;
        }

        public void ExibirMenuAutenticacao()
        {
            Console.Clear();
            Console.WriteLine("=================================");
            Console.WriteLine("         LOGIN - NEXO            ");
            Console.WriteLine("=================================");
            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Senha: ");
            string senha = Console.ReadLine();

            bool sucesso = _autenticacaoController.Login(email, senha);

            if (sucesso)
            {
                Console.WriteLine("\nLogin efetuado com sucesso!");
            }
            else
            {
                Console.WriteLine("\nFalha na autenticação. Verifique o email e a senha.");
            }
        }
    }
}