using NEXO.Controllers;
using System;

namespace NEXO.Views
{
    public class MenuView
    {
        private readonly CatalogoController _catalogoController;

        public MenuView(CatalogoController catalogoController)
        {
            _catalogoController = catalogoController;
        }

        public void ExibirMenuPlataformas()
        {
            bool executando = true;

            while (executando)
            {
                Console.Clear();
                Console.WriteLine("=================================");
                Console.WriteLine("    CATÁLOGO DE JOGOS - NEXO     ");
                Console.WriteLine("=================================");
                Console.WriteLine("1. Nintendo Switch");
                Console.WriteLine("2. PlayStation 5");
                Console.WriteLine("3. Xbox Series X/S");
                Console.WriteLine("4. PC");
                Console.WriteLine("5. Ver Todos os Jogos");
                Console.WriteLine("0. Sair");
                Console.WriteLine("=================================");
                Console.Write("Escolha uma opção: ");

                string opcao = Console.ReadLine();

                Console.Clear();
                switch (opcao)
                {
                    case "1":
                        _catalogoController.ListarPorPlataforma("Nintendo Switch");
                        break;
                    case "2":
                        _catalogoController.ListarPorPlataforma("PlayStation 5");
                        break;
                    case "3":
                        _catalogoController.ListarPorPlataforma("Xbox Series X/S");
                        break;
                    case "4":
                        _catalogoController.ListarPorPlataforma("PC");
                        break;
                    case "5":
                        _catalogoController.ListarTodos();
                        break;
                    case "0":
                        executando = false;
                        Console.WriteLine("A encerrar a aplicação...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida! Pressione ENTER para tentar novamente.");
                        break;
                }

                if (executando)
                {
                    Console.WriteLine("\nPressione ENTER para voltar ao menu...");
                    Console.ReadLine();
                }
            }
        }
    }
}