namespace NEXO.model
{
    public class Produto
    {
        public int Id_produtos { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public string Plataforma { get; set; }
        public float Preco { get; set; }
        public int Pontos_ganhos { get; set; }
    }
}