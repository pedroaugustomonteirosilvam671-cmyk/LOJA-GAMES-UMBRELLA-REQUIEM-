namespace NEXO.model
{
    public class Usuario
    {
        public int Id_usuario { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha_hash { get; set; }
    }
}