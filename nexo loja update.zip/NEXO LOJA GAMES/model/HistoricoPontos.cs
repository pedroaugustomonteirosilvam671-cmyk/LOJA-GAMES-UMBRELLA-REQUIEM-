using System;

namespace NEXO.model
{
    public class HistoricoPontos
    {
        public int Id_historico_pontos { get; set; }
        public int IdUsuario { get; set; }
        public int IdProdutos { get; set; }
        public float Pontos { get; set; }
        public DateTime Data_compra { get; set; }
    }
}