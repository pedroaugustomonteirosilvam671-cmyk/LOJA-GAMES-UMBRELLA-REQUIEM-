using System;
using NEXO.services;

namespace NEXO.Controllers
{
    public class AutenticacaoController
    {
        private readonly UsuarioService _usuarioService;

        public AutenticacaoController(UsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        public bool Login(string email, string senha)
        {
            var usuario = _usuarioService.Autenticar(email, senha);
            if (usuario != null)
            {
                SessaoUsuario.IniciarSessao(usuario);
                return true;
            }
            return false;
        }
    }
}