using System;
using NEXO.services;

namespace NEXO.Controllers
{
    public class CatalogoController
    {
        private readonly ProdutoService _produtoService;

       
        public CatalogoController(ProdutoService produtoService)
        {
            _produtoService = produtoService;
        }

        
        public void ListarPorPlataforma(string plataforma)
        {
            Console.WriteLine($"--- JOGOS PARA {plataforma.ToUpper()} ---");
        }

        public void ListarTodos()
        {
            Console.WriteLine("--- TODOS OS JOGOS ---");
        }
    }
}