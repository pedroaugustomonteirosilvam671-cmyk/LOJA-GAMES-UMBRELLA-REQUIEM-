using System.Security.Cryptography;
using System.Text;

namespace NEXO.services
{
    public class SenhaService
    {
        public string GerarHash(string senha)
        {
            using (var sha256 =SHA256.Create())
            {
                byte[] bytes = sha256. ComputeHash(Encoding.UTF8.GetBytes(senha));
                var builder = new StringBuilder();
                foreach (var b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
                 }
             }

                public bool VerificarSenha(string senhaDigitada, string hashSalvo)
                {
                    string hashDigitada = GerarHash(senhaDigitada);
                    return hashDigitada.Equals(hashSalvo);
                }
            }
        }
    
