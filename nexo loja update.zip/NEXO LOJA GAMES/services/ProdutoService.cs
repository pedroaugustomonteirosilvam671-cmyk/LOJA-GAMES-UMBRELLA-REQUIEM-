using NEXO.model;
using NEXO.data;
using System.Collections.Generic;

namespace NEXO.services
{

    public class ProdutoService
    {
        private readonly Conexao _conexao;

        public ProdutoService(Conexao conexao)
        {
            _conexao = conexao;
        }

        public List<Produto> ObterTodos()
        {
            return new List<Produto>();
        }

        public List<Produto> ObterPorPlataforma(string plataforma)
        {
            return new List<Produto>();
        }
    }
}