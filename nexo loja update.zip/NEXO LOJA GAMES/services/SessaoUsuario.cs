using NEXO.model;

namespace NEXO.services
{
    public static class SessaoUsuario
    {
        public static Usuario UsuarioLogado { get; private set; }

        public static void IniciarSessao(Usuario usuario)
        {
            UsuarioLogado = usuario;
        }

        public static void EncerrarSessao()
        {
            UsuarioLogado= null;
        }

        public static bool EstaAutenticado()
    {
        return UsuarioLogado != null; 
    }
    }
}