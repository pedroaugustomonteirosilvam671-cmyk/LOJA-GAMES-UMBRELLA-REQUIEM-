using System;
using MySqlConnector;
using NEXO.data;
using NEXO.model;

namespace NEXO.services
{

    public class UsuarioService
    {

        private readonly Conexao _conexao;
        private readonly SenhaService _senhaService;

        public UsuarioService(Conexao conexao, SenhaService senhaService)
        {
            _conexao = conexao;
            _senhaService = senhaService;
        }

        public Usuario Autenticar(string email, string senha)
    {

        return null;
        }
    }
}