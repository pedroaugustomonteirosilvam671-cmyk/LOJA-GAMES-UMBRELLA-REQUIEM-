using System.Data.SQLite;

namespace NEXO.data
{
    public class Conexao
    {
        private readonly string _connectionString = "Data Source=nexo.db;Version=3;";

        public SQLiteConnection ObterConexao()
        {
            var conexao = new SQLiteConnection(_connectionString);
            conexao.Open();
            return conexao;
        }
    }
}
